
package com.tama.receiptapp

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.*
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { ReceiptScreen() } } }
    }
}

// ====== Konfigurasi Bisnis ======
private const val BUSINESS_NAME = "Tama Ideas Rent"
private const val DEFAULT_WA_NUMBER = "62812XXXXXXX"
private const val DEFAULT_BRANCH_CODE = "JKT"

// ====== Tarif ======
private val TARIF_PER_KM = 3500.0
private val BASE_TARIF = mapOf(
    "Drop off" to 100_000.0,
    "Pulang pergi" to 200_000.0,
    "Sewa 6 jam" to 150_000.0,
    "Sewa 12 jam" to 250_000.0,
    "Sewa 18 jam" to 350_000.0,
)

private val JENIS_OPTIONS = listOf("Drop off", "Pulang pergi", "Sewa 6 jam", "Sewa 12 jam", "Sewa 18 jam")
private val METODE_BAYAR = listOf("Tunai", "Transfer", "QRIS")

@Composable
fun ReceiptScreen() {
    val ctx = LocalContext.current

    var branchCode by remember { mutableStateOf(DEFAULT_BRANCH_CODE) }
    var invoiceNo by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }
    var distanceKmText by remember { mutableStateOf("") }
    var driverName by remember { mutableStateOf("") }
    var origin by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var jenis by remember { mutableStateOf(JENIS_OPTIONS.first()) }
    var metode by remember { mutableStateOf(METODE_BAYAR.first()) }
    var dueDate by remember { mutableStateOf("") } // yyyy-MM-dd
    var dueDateError by remember { mutableStateOf<String?>(null) }
    var isPaid by remember { mutableStateOf(false) }
    var waNumber by remember { mutableStateOf(DEFAULT_WA_NUMBER) }

    LaunchedEffect(Unit) {
        if (invoiceNo.isBlank()) invoiceNo = generateNextInvoiceNo(ctx, branchCode)
        if (dueDate.isBlank()) dueDate = computeDueDateString(jenis)
    }
    LaunchedEffect(jenis) {
        if (dueDate.isBlank()) dueDate = computeDueDateString(jenis)
    }

    val distanceKm = distanceKmText.toDoubleOrNull() ?: 0.0
    val base = BASE_TARIF[jenis] ?: 0.0
    val distanceCost = distanceKm * TARIF_PER_KM
    val total = base + distanceCost

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Header()
        Spacer(Modifier.height(12.dp))

        Card(shape = RoundedCornerShape(10.dp), backgroundColor = Color(0xFFF5F5F5), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(branchCode, { branchCode = it.uppercase() }, label = { Text("Kode Cabang (mis. JKT)") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(invoiceNo, { invoiceNo = it.uppercase() }, label = { Text("No. Invoice (otomatis)") }, modifier = Modifier.weight(1.3f))
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { invoiceNo = generateNextInvoiceNo(ctx, branchCode) }) { Text("Generate") }
                }

                Spacer(Modifier.height(8.dp))
                OutlinedTextField(customerName, { customerName = it }, label = { Text("Nama Pelanggan") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(driverName, { driverName = it }, label = { Text("Nama Pengemudi") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(distanceKmText, { txt -> if (txt.isEmpty() || txt.matches(Regex("^\\d*(\\.\\d*)?$"))) distanceKmText = txt },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Jarak (km)") }, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(origin, { origin = it }, label = { Text("Asal") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(destination, { destination = it }, label = { Text("Tujuan") }, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                JenisDropdown(selected = jenis, onSelect = { jenis = it })
                Spacer(Modifier.height(8.dp))
                MetodeDropdown(selected = metode, onSelect = { metode = it })
                Spacer(Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = dueDate,
                            onValueChange = {
                                dueDate = it
                                dueDateError = if (it.isBlank()) null else if (isValidDateStrict(it, "yyyy-MM-dd")) null else "Format tanggal salah (yyyy-MM-dd)"
                            },
                            label = { Text("Jatuh Tempo (yyyy-MM-dd)") },
                            isError = dueDateError != null,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (dueDateError != null) Text(dueDateError ?: "", color = Color(0xFFD32F2F), fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { dueDate = computeDueDateString(jenis) }) { Text("Atur Otomatis") }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPaid, onCheckedChange = { isPaid = it })
                    Text("Tandai LUNAS")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(waNumber, { waNumber = it }, label = { Text("Nomor WhatsApp Tujuan (62...)") }, modifier = Modifier.fillMaxWidth())

                Spacer(Modifier.height(12.dp))
                Divider(); Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tarif dasar (${jenis})", fontWeight = FontWeight.Medium)
                    Text(formatRupiah(base), fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Jarak ${"%.2f".format(distanceKm)} km x ${formatRupiah(TARIF_PER_KM)}")
                    Text(formatRupiah(distanceCost))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("TOTAL", fontWeight = FontWeight.Bold)
                    Text(formatRupiah(total), fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(modifier = Modifier.weight(1f), onClick = {
                if (dueDate.isNotBlank() && !isValidDateStrict(dueDate, "yyyy-MM-dd")) { Toast.makeText(ctx, "Format jatuh tempo tidak valid", Toast.LENGTH_SHORT).show(); return@Button }
                val file = createReceiptPdfFile(
                    context = ctx,
                    filename = "receipt_${System.currentTimeMillis()}.pdf",
                    title = BUSINESS_NAME,
                    invoiceNo = invoiceNo,
                    branchCode = branchCode,
                    customer = customerName,
                    driver = driverName,
                    origin = origin,
                    destination = destination,
                    jenis = jenis,
                    distanceKm = distanceKm,
                    base = base,
                    perKm = TARIF_PER_KM,
                    total = total,
                    metode = metode,
                    dueDate = dueDate,
                    isPaid = isPaid,
                    logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_tama_logo),
                    qris = if (metode == "QRIS") BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_qris) else null,
                    gradientHeader = true,
                )
                if (file != null) Toast.makeText(ctx, "Tersimpan: ${file.absolutePath}", Toast.LENGTH_LONG).show()
                else Toast.makeText(ctx, "Gagal menyimpan PDF", Toast.LENGTH_SHORT).show()
            }) { Text("Simpan (App Files)") }

            Button(modifier = Modifier.weight(1f), onClick = {
                if (dueDate.isNotBlank() && !isValidDateStrict(dueDate, "yyyy-MM-dd")) { Toast.makeText(ctx, "Format jatuh tempo tidak valid", Toast.LENGTH_SHORT).show(); return@Button }
                val bytes = createReceiptPdfBytes(
                    context = ctx,
                    title = BUSINESS_NAME,
                    invoiceNo = invoiceNo,
                    branchCode = branchCode,
                    customer = customerName,
                    driver = driverName,
                    origin = origin,
                    destination = destination,
                    jenis = jenis,
                    distanceKm = distanceKm,
                    base = base,
                    perKm = TARIF_PER_KM,
                    total = total,
                    metode = metode,
                    dueDate = dueDate,
                    isPaid = isPaid,
                    logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_tama_logo),
                    qris = if (metode == "QRIS") BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_qris) else null,
                    gradientHeader = true,
                )
                if (bytes != null && savePdfToDownloads(ctx, "receipt_${System.currentTimeMillis()}.pdf", bytes))
                    Toast.makeText(ctx, "Tersimpan ke Downloads", Toast.LENGTH_LONG).show()
                else Toast.makeText(ctx, "Gagal simpan ke Downloads", Toast.LENGTH_SHORT).show()
            }) { Text("Simpan ke Downloads") }
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(modifier = Modifier.weight(1f), onClick = {
                if (dueDate.isNotBlank() && !isValidDateStrict(dueDate, "yyyy-MM-dd")) { Toast.makeText(ctx, "Format jatuh tempo tidak valid", Toast.LENGTH_SHORT).show(); return@Button }
                val bytes = createReceiptPdfBytes(
                    context = ctx,
                    title = BUSINESS_NAME,
                    invoiceNo = invoiceNo,
                    branchCode = branchCode,
                    customer = customerName,
                    driver = driverName,
                    origin = origin,
                    destination = destination,
                    jenis = jenis,
                    distanceKm = distanceKm,
                    base = base,
                    perKm = TARIF_PER_KM,
                    total = total,
                    metode = metode,
                    dueDate = dueDate,
                    isPaid = isPaid,
                    logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_tama_logo),
                    qris = if (metode == "QRIS") BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_qris) else null,
                    gradientHeader = true,
                )
                val temp = bytes?.let { writeTempPdf(ctx, it) }
                val msg = buildShareTextFormal(invoiceNo, branchCode, customerName, driverName, origin, destination, jenis, distanceKm, metode, dueDate, total, isPaid)
                if (temp != null) shareViaWhatsAppToNumber(ctx, temp, msg, waNumber)
                else Toast.makeText(ctx, "Gagal membuat PDF", Toast.LENGTH_SHORT).show()
            }) { Text("WA ke Nomor") }

            Button(modifier = Modifier.weight(1f), onClick = {
                if (dueDate.isNotBlank() && !isValidDateStrict(dueDate, "yyyy-MM-dd")) { Toast.makeText(ctx, "Format jatuh tempo tidak valid", Toast.LENGTH_SHORT).show(); return@Button }
                val bytes = createReceiptPdfBytes(
                    context = ctx,
                    title = BUSINESS_NAME,
                    invoiceNo = invoiceNo,
                    branchCode = branchCode,
                    customer = customerName,
                    driver = driverName,
                    origin = origin,
                    destination = destination,
                    jenis = jenis,
                    distanceKm = distanceKm,
                    base = base,
                    perKm = TARIF_PER_KM,
                    total = total,
                    metode = metode,
                    dueDate = dueDate,
                    isPaid = isPaid,
                    logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_tama_logo),
                    qris = if (metode == "QRIS") BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_qris) else null,
                    gradientHeader = true,
                )
                val temp = bytes?.let { writeTempPdf(ctx, it) }
                val msg = buildShareTextFormal(invoiceNo, branchCode, customerName, driverName, origin, destination, jenis, distanceKm, metode, dueDate, total, isPaid)
                if (temp != null) shareViaEmail(ctx, temp, msg, subject = "Invoice $invoiceNo — $BUSINESS_NAME")
                else Toast.makeText(ctx, "Gagal membuat PDF", Toast.LENGTH_SHORT).show()
            }) { Text("Email (Subjek + Ringkas)") }
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { PermissionHint() }
    }
}

@Composable
private fun Header() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF0D47A1), Color(0xFF42A5F5))), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(painter = painterResource(id = R.drawable.ic_tama_logo), contentDescription = "Logo", modifier = Modifier.size(44.dp).clip(CircleShape))
            Text(text = "$BUSINESS_NAME — Receipt", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun JenisDropdown(selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text("Jenis Perjalanan", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.background(Color.White, RoundedCornerShape(8.dp)).clickable { expanded = true }.padding(12.dp).fillMaxWidth()) { Text(selected) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { JENIS_OPTIONS.forEach { DropdownMenuItem(onClick = { onSelect(it); expanded = false }) { Text(it) } } }
    }
}

@Composable
private fun MetodeDropdown(selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text("Metode Pembayaran", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.background(Color.White, RoundedCornerShape(8.dp)).clickable { expanded = true }.padding(12.dp).fillMaxWidth()) { Text(selected) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { METODE_BAYAR.forEach { DropdownMenuItem(onClick = { onSelect(it); expanded = false }) { Text(it) } } }
    }
}

@Composable
private fun PermissionHint() {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    if (!granted) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Izin penyimpanan diperlukan untuk simpan ke Downloads pada perangkat lama.")
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = { ActivityCompat.requestPermissions(activity!!, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 101) }) { Text("Izinkan") }
        }
    }
}

// ====== PDF builders, share, util (same as canvas latest) ======
fun createReceiptPdfBytes(
    context: Context,
    title: String,
    invoiceNo: String,
    branchCode: String,
    customer: String,
    driver: String,
    origin: String,
    destination: String,
    jenis: String,
    distanceKm: Double,
    base: Double,
    perKm: Double,
    total: Double,
    metode: String,
    dueDate: String,
    isPaid: Boolean,
    logo: Bitmap?,
    qris: Bitmap?,
    gradientHeader: Boolean = true,
): ByteArray? {
    return try {
        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        var y = 30f

        if (gradientHeader) {
            val shader = LinearGradient(0f, 0f, pageWidth.toFloat(), 0f, intArrayOf(Color.parseColor("#0D47A1"), Color.parseColor("#42A5F5")), null, Shader.TileMode.CLAMP)
            paint.shader = shader
            canvas.drawRoundRect(RectF(15f, 15f, pageWidth - 15f, 85f), 16f, 16f, paint)
            paint.shader = null
            logo?.let { bmp -> canvas.drawBitmap(makeCircularBitmap(bmp, 48), 25f, 25f, null) }
            paint.color = Color.WHITE; paint.textSize = 18f; paint.isFakeBoldText = true
            canvas.drawText(title, 90f, 45f, paint)
            paint.textSize = 12f; paint.isFakeBoldText = false
            canvas.drawText("Invoice: ${invoiceNo.ifBlank { "-" }}", 90f, 65f, paint)
            paint.color = Color.BLACK
            y = 100f
        } else {
            paint.textSize = 16f; paint.isFakeBoldText = true; canvas.drawText(title, 20f, y, paint); paint.isFakeBoldText = false; paint.textSize = 12f; y += 20f
        }

        canvas.drawText("Cabang: ${branchCode.ifBlank { "-" }}", 20f, y, paint); y += 18f
        canvas.drawText("Tanggal: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}", 20f, y, paint); y += 10f
        canvas.drawText("--------------------------------------------", 20f, y, paint); y += 20f

        fun line(label: String, value: String) { canvas.drawText(label, 20f, y, paint); val tw = paint.measureText(value); canvas.drawText(value, pageWidth - 20 - tw, y, paint) }

        line("Nama Pelanggan", customer.ifBlank { "-" }); y += 18f
        line("Nama Pengemudi", driver.ifBlank { "-" }); y += 18f
        line("Asal", origin.ifBlank { "-" }); y += 18f
        line("Tujuan", destination.ifBlank { "-" }); y += 18f
        line("Jenis", jenis); y += 18f
        line("Jarak (km)", String.format(Locale.getDefault(), "%.2f", distanceKm)); y += 18f
        line("Metode", metode); y += 18f
        if (dueDate.isNotBlank()) { line("Jatuh Tempo", dueDate); y += 18f }

        y += 6f; canvas.drawText("--------------------------------------------", 20f, y, paint); y += 20f
        line("Tarif dasar", formatRupiah(base)); y += 18f
        line("Tarif jarak (${String.format(Locale.getDefault(), "%.2f", distanceKm)} km x ${formatRupiah(perKm)})", formatRupiah(distanceKm * perKm)); y += 18f
        paint.isFakeBoldText = true; line("TOTAL", formatRupiah(total)); paint.isFakeBoldText = false

        qris?.let { q ->
            val left = 20f; val top = y + 20f
            val size = 140
            canvas.drawText("Pembayaran QRIS", left, top - 6f, paint)
            canvas.drawBitmap(Bitmap.createScaledBitmap(q, size, size, true), left, top, null)
            y = top + size + 10f
        }

        if (isPaid) {
            val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2200C853"); textSize = 64f; isFakeBoldText = true }
            val text = "L U N A S"; val angle = -25f
            canvas.save(); canvas.rotate(angle, pageWidth/2f, pageHeight/2f)
            val tw = wmPaint.measureText(text)
            canvas.drawText(text, pageWidth/2f - tw/2, pageHeight/2f, wmPaint)
            canvas.restore()
        }

        document.finishPage(page)
        val bos = ByteArrayOutputStream(); document.writeTo(bos); document.close(); bos.toByteArray()
    } catch (e: Exception) { e.printStackTrace(); null }
}

fun createReceiptPdfFile(
    context: Context,
    filename: String,
    title: String,
    invoiceNo: String,
    branchCode: String,
    customer: String,
    driver: String,
    origin: String,
    destination: String,
    jenis: String,
    distanceKm: Double,
    base: Double,
    perKm: Double,
    total: Double,
    metode: String,
    dueDate: String,
    isPaid: Boolean,
    logo: Bitmap?,
    qris: Bitmap?,
    gradientHeader: Boolean = true,
): File? {
    val bytes = createReceiptPdfBytes(context, title, invoiceNo, branchCode, customer, driver, origin, destination, jenis, distanceKm, base, perKm, total, metode, dueDate, isPaid, logo, qris, gradientHeader)
    return try { if (bytes == null) null else File(context.getExternalFilesDir(null), filename).apply { FileOutputStream(this).use { it.write(bytes) } } } catch (e: Exception) { e.printStackTrace(); null }
}

fun savePdfToDownloads(context: Context, displayName: String, data: ByteArray): Boolean {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ReceiptApp")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            resolver.openOutputStream(uri)?.use { it.write(data) } ?: return false
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } else {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!dir.exists()) dir.mkdirs()
            FileOutputStream(File(dir, displayName)).use { it.write(data) }
            true
        }
    } catch (e: Exception) { e.printStackTrace(); false }
}

private fun buildShareTextFormal(
    invoiceNo: String,
    branchCode: String,
    customer: String,
    driver: String,
    origin: String,
    destination: String,
    jenis: String,
    distanceKm: Double,
    metode: String,
    dueDate: String,
    total: Double,
    isPaid: Boolean
): String {
    val t = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
    val status = if (isPaid) "LUNAS" else "BELUM LUNAS"
    val jatuhTempoLine = if (!isPaid && dueDate.isNotBlank()) "\\nJatuh Tempo : $dueDate" else ""
    return "${BUSINESS_NAME}\\nCabang : ${branchCode.ifBlank { "-" }}\\nInvoice : ${invoiceNo.ifBlank { "-" }}\\nTanggal : $t\\nPelanggan : ${customer.ifBlank { "-" }}\\nPengemudi : ${driver.ifBlank { "-" }}\\nRute : ${origin.ifBlank { "-" }} → ${destination.ifBlank { "-" }}\\nJenis : $jenis (±${"%.2f".format(distanceKm)} km)\\nMetode : $metode$jatuhTempoLine\\nTotal : ${formatRupiah(total)}\\nStatus : $status"
}

private fun writeTempPdf(context: Context, data: ByteArray): File? = try {
    File(context.getExternalFilesDir(null), "share_${System.currentTimeMillis()}.pdf").apply { FileOutputStream(this).use { it.write(data) } }
} catch (e: Exception) { e.printStackTrace(); null }

private fun shareViaWhatsAppToNumber(context: Context, file: File, message: String, phone: String) {
    try {
        val url = "https://wa.me/$phone?text=" + URLEncoder.encode(message, "UTF-8")
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: Exception) {}
    val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        setPackage("com.whatsapp")
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try { context.startActivity(intent) } catch (_: Exception) { Toast.makeText(context, "Gagal membuka WhatsApp", Toast.LENGTH_SHORT).show() }
}

private fun shareViaEmail(context: Context, file: File, message: String, subject: String) {
    val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, message)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Kirim via Email"))
}

fun formatRupiah(value: Double): String { val locale = Locale("id", "ID"); val format = NumberFormat.getCurrencyInstance(locale); return format.format(value) }

private fun isValidDateStrict(text: String, pattern: String): Boolean {
    return try {
        val sdf = SimpleDateFormat(pattern, Locale.getDefault())
        sdf.isLenient = false
        val date = sdf.parse(text) ?: return false
        sdf.format(date) == text
    } catch (e: ParseException) { false }
}

private fun computeDueDateString(jenis: String, pattern: String = "yyyy-MM-dd"): String {
    val plusDays = when (jenis) {
        "Drop off" -> 1
        "Pulang pergi" -> 2
        "Sewa 6 jam", "Sewa 12 jam", "Sewa 18 jam" -> 0
        else -> 0
    }
    val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_MONTH, plusDays)
    val sdf = SimpleDateFormat(pattern, Locale.getDefault())
    return sdf.format(cal.time)
}

private const val PREFS_NAME = "receipt_prefs"
private const val KEY_SEQ_MONTH = "seq_month"
private const val KEY_SEQ_COUNTER = "seq_counter"
private const val KEY_SEQ_BRANCH = "seq_branch"

private fun generateNextInvoiceNo(context: Context, branchCode: String): String {
    val code = branchCode.ifBlank { DEFAULT_BRANCH_CODE }.uppercase()
    val cal = Calendar.getInstance()
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH) + 1
    val ym = String.format(Locale.getDefault(), "%04d%02d", year, month)

    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val storedYm = prefs.getString(KEY_SEQ_MONTH, null)
    val storedBranch = prefs.getString(KEY_SEQ_BRANCH, null)
    var counter = prefs.getInt(KEY_SEQ_COUNTER, 0)

    if (storedYm != ym || storedBranch != code) {
        counter = 1
        prefs.edit().putString(KEY_SEQ_MONTH, ym).putString(KEY_SEQ_BRANCH, code).putInt(KEY_SEQ_COUNTER, counter).apply()
    } else {
        counter += 1
        prefs.edit().putInt(KEY_SEQ_COUNTER, counter).apply()
    }

    val seq = String.format(Locale.getDefault(), "%04d", counter)
    return "TIR-$code-$ym-$seq"
}
